Application for viewing and editing class diagrams and sequence diagrams
Authors:
        Engeniya Taipova   (xtaipo00)
        Vladyslav Kovalets (xkoval21)
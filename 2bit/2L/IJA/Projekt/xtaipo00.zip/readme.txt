Project Java 2021/2022

Authors:
        Taipova Evgeniya xtaipo00
        Kovalets Vladyslav xkoval21

Description of the project:
        An application for displaying and editing class diagrams and sequence diagrams.
        To implement the project Java SE 11 is used.
        For the graphical user interface project use JavaFX.

Build:
       We left the creation of maven to the last moment and didn't cope with it. We are very sorry. Project always started with build and run in IntelliJ IDEA 2021.3.2
xtaipo00.iml helps.
